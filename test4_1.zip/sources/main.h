#ifndef MAIN_H        /*prevent duplicated includes*/
#define MAIN_H

#include "projectglobals.h"
#include "interrupt.h"
#include "lcd.h"

#endif /*MAIN_H*/