HCS12 Software Stationery
==========================
For more information on how to use the HCS12 Software Stationery package, refer to the
Stationery\HC12\HCS12_Stationery\Support_Files\documentation directory of your installation.

_DP256_K79X Project - Version 1.0 - 08/29/2003

Version 1.0 - Log
==================
+ Completed MC9S12DP256 (K79X) Project. 

